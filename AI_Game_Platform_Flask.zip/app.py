from flask import Flask
from routes.game_routes import game_bp
from routes.ai_routes import ai_bp

app = Flask(__name__)
app.register_blueprint(game_bp)
app.register_blueprint(ai_bp)

if __name__ == '__main__':
    app.run(debug=True)