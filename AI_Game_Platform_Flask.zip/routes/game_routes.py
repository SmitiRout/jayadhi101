from flask import Blueprint, jsonify
import json

game_bp = Blueprint('game', __name__)

@game_bp.route('/game/prompts', methods=['GET'])
def get_prompts():
    with open('game_prompts/prompts.json') as f:
        data = json.load(f)
    return jsonify(data)