from flask import Blueprint, request, jsonify
from models.ai_model import predict_label
from models.adaptive import adjust_difficulty

ai_bp = Blueprint('ai', __name__)

@ai_bp.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    features = data.get("features", [])
    label = predict_label(features)
    return jsonify({"prediction": label})

@ai_bp.route('/adapt', methods=['POST'])
def adapt():
    stats = request.get_json()
    level = adjust_difficulty(stats)
    return jsonify({"next_difficulty": level})