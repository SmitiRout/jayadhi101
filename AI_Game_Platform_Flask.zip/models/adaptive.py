def adjust_difficulty(stats):
    accuracy = stats.get("accuracy", 0)
    if accuracy >= 85:
        return "medium"
    elif accuracy < 60:
        return "easy"
    else:
        return "current"