def predict_label(features):
    # Dummy logic for demonstration
    return "cookie" if features[0] > 0.5 else "cupcake"